import { useState } from 'react';

export function EstimatorView() {
  const [engineers, setEngineers] = useState(24);
  const [hardwareKits, setHardwareKits] = useState(12);
  const [cadence, setCadence] = useState<'Weekly' | 'Bi-weekly'>('Weekly');
  const [supportTier, setSupportTier] = useState<'Standard' | 'Dedicated'>('Standard');

  // Transparent deterministic calculations
  const seatRate = supportTier === 'Dedicated' ? 58 : 42;
  const kitRate = 25;
  const monthlyInvestment = engineers * seatRate + hardwareKits * kitRate;

  // Engineering hours reclaimed per month from consolidated milestone & ledger reviews
  const cadenceFactor = cadence === 'Weekly' ? 1.0 : 0.72;
  const hoursSavedMonthly = Math.round((engineers * 2.4 + hardwareKits * 1.1) * cadenceFactor);
  const blendedHourlyCost = 115;
  const grossMonthlyValue = hoursSavedMonthly * blendedHourlyCost;
  const netMonthlySavings = grossMonthlyValue - monthlyInvestment;
  const paybackWeeks = Math.max(
    1,
    Math.round((monthlyInvestment / Math.max(1, grossMonthlyValue / 4.33)) * 10) / 10
  );

  const quarters = [
    { label: 'Quarter 1', manualCost: grossMonthlyValue * 3, platformCost: monthlyInvestment * 3 },
    { label: 'Quarter 2', manualCost: grossMonthlyValue * 6, platformCost: monthlyInvestment * 6 },
    { label: 'Quarter 3', manualCost: grossMonthlyValue * 9, platformCost: monthlyInvestment * 9 },
    { label: 'Quarter 4', manualCost: grossMonthlyValue * 12, platformCost: monthlyInvestment * 12 },
  ];

  return (
    <div className="space-y-8 pb-16">
      <div className="space-y-1 max-w-2xl">
        <h1 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900">
          Capacity &amp; Cost Estimator
        </h1>
        <p className="text-sm text-slate-600">
          Adjust active engineering seats, hardware kit volume, and review cadence to model monthly run-rate and engineering hours reclaimed.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Controls Column */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label htmlFor="est-engineers" className="text-sm font-medium text-slate-900">
                Active Engineers
              </label>
              <span className="font-mono text-sm font-semibold text-blue-700 tabular-nums">
                {engineers} seats
              </span>
            </div>
            <input
              id="est-engineers"
              type="range"
              min={5}
              max={100}
              step={1}
              value={engineers}
              onChange={(e) => setEngineers(Number(e.target.value))}
              className="w-full accent-blue-700 cursor-pointer"
            />
            <div className="flex justify-between text-xs text-slate-500 font-mono tabular-nums">
              <span>5</span>
              <span>50</span>
              <span>100</span>
            </div>
          </div>

          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <label htmlFor="est-kits" className="text-sm font-medium text-slate-900">
                Tracked Hardware Kits
              </label>
              <span className="font-mono text-sm font-semibold text-blue-700 tabular-nums">
                {hardwareKits} kits
              </span>
            </div>
            <input
              id="est-kits"
              type="range"
              min={0}
              max={50}
              step={1}
              value={hardwareKits}
              onChange={(e) => setHardwareKits(Number(e.target.value))}
              className="w-full accent-blue-700 cursor-pointer"
            />
            <div className="flex justify-between text-xs text-slate-500 font-mono tabular-nums">
              <span>0</span>
              <span>25</span>
              <span>50</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
            <div className="space-y-2">
              <span className="block text-xs font-medium text-slate-700">
                Review Cadence
              </span>
              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
                {(['Weekly', 'Bi-weekly'] as const).map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setCadence(option)}
                    className={`py-1.5 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      cadence === option
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <span className="block text-xs font-medium text-slate-700">
                Support Tier
              </span>
              <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
                {(['Standard', 'Dedicated'] as const).map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setSupportTier(option)}
                    className={`py-1.5 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      supportTier === option
                        ? 'bg-white text-slate-900 shadow-sm'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Live Output Column */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-1">
                <span className="text-xs font-medium text-slate-500">
                  Monthly Platform Cost
                </span>
                <div className="font-mono text-2xl sm:text-3xl font-semibold text-slate-900 tabular-nums">
                  ${monthlyInvestment.toLocaleString()}
                </div>
                <span className="text-xs text-slate-500">
                  ${seatRate}/seat + ${kitRate}/kit
                </span>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-medium text-slate-500">
                  Hours Reclaimed / Mo
                </span>
                <div className="font-mono text-2xl sm:text-3xl font-semibold text-blue-700 tabular-nums">
                  {hoursSavedMonthly} hrs
                </div>
                <span className="text-xs text-slate-500">
                  At ${blendedHourlyCost}/hr blended rate
                </span>
              </div>

              <div className="space-y-1 pt-4 border-t border-slate-100">
                <span className="text-xs font-medium text-slate-500">
                  Net Monthly Savings
                </span>
                <div className="font-mono text-xl sm:text-2xl font-semibold text-emerald-700 tabular-nums">
                  ${netMonthlySavings.toLocaleString()}
                </div>
              </div>

              <div className="space-y-1 pt-4 border-t border-slate-100">
                <span className="text-xs font-medium text-slate-500">
                  Estimated Payback
                </span>
                <div className="font-mono text-xl sm:text-2xl font-semibold text-slate-900 tabular-nums">
                  {paybackWeeks} weeks
                </div>
              </div>
            </div>
          </div>

          {/* 12-Month Cumulative Breakdown */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100">
              <h2 className="font-display text-base font-semibold text-slate-900">
                12-Month Cumulative Comparison
              </h2>
            </div>
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 text-xs font-medium text-slate-500">
                  <th className="py-2.5 px-6">Horizon</th>
                  <th className="py-2.5 px-6 text-right">Manual Overhead</th>
                  <th className="py-2.5 px-6 text-right">Kestrel Cost</th>
                  <th className="py-2.5 px-6 text-right">Net Gain</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {quarters.map((q) => (
                  <tr key={q.label} className="h-[40px]">
                    <td className="py-2 px-6 font-medium text-slate-800">{q.label}</td>
                    <td className="py-2 px-6 text-right font-mono tabular-nums text-slate-600">
                      ${q.manualCost.toLocaleString()}
                    </td>
                    <td className="py-2 px-6 text-right font-mono tabular-nums text-slate-600">
                      ${q.platformCost.toLocaleString()}
                    </td>
                    <td className="py-2 px-6 text-right font-mono tabular-nums font-semibold text-emerald-700">
                      +${(q.manualCost - q.platformCost).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
