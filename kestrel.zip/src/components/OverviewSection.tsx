import { useState, FormEvent } from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import {
  HERO_IMAGE,
  FIELD_UNIT_IMAGE,
  MODULAR_RACK_IMAGE,
  CLAIRE_PORTRAIT_IMAGE,
} from '../data/demoData';
import { ResilientImage } from './ResilientImage';

export type AppView = 'overview' | 'workspace' | 'ledger' | 'estimator';

interface OverviewSectionProps {
  onNavigate: (view: AppView, programFilter?: string) => void;
}

export function OverviewSection({ onNavigate }: OverviewSectionProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [teamSize, setTeamSize] = useState('15–40 engineers');
  const [errorMsg, setErrorMsg] = useState('');
  const [submittedEmail, setSubmittedEmail] = useState<string | null>(null);

  function handleWalkthroughSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();

    if (trimmedName.length < 2) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setErrorMsg('Please enter a valid work email address.');
      return;
    }

    setErrorMsg('');
    setSubmittedEmail(trimmedEmail);
  }

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-between py-2">
          <div className="space-y-6">
            <p className="text-sm font-medium text-blue-700">
              Munich · Seattle · Osaka Engineering Operations
            </p>
            <h1 className="font-display text-[clamp(2.25rem,4vw,3.75rem)] leading-[1.06] tracking-tight font-semibold text-slate-900 text-balance">
              Precision planning for hardware and field teams.
            </h1>
            <p className="text-base sm:text-lg leading-relaxed text-slate-600 max-w-xl">
              Coordinate prototype tolerances, multi-site lab schedules, and batch spend from a single structured workspace—built to replace fragmented spreadsheets before production lock.
            </p>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={() => onNavigate('workspace')}
              className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-offset-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Open Live Workspace</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('estimator')}
              className="inline-flex items-center px-4 py-3 text-sm font-medium text-slate-700 hover:text-slate-900 border border-slate-200 bg-white hover:bg-slate-50 rounded-lg transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-offset-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Run Cost Estimator
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-full min-h-[280px] lg:min-h-[420px] rounded-xl overflow-hidden border border-slate-200 bg-white">
            <ResilientImage
              src={HERO_IMAGE}
              alt="Hardware engineers reviewing aluminum prototype enclosures and technical drawings inside a sunlit studio"
              fallbackTitle="Engineering Studio Workspace"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* 4-Column Quantitative Proof Strip */}
      <section aria-label="Operational benchmarks" className="border-y border-slate-200 bg-white rounded-xl border px-6 py-6 sm:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          <div className="space-y-1">
            <div className="font-mono text-2xl sm:text-3xl font-semibold text-slate-900 tabular-nums">
              38% Faster
            </div>
            <p className="text-sm text-slate-600">
              Prototype sign-off cycle across Q3 hardware batches
            </p>
          </div>
          <div className="space-y-1">
            <div className="font-mono text-2xl sm:text-3xl font-semibold text-slate-900 tabular-nums">
              14.2 hrs/wk
            </div>
            <p className="text-sm text-slate-600">
              Weekly engineering lead time reclaimed from status syncs
            </p>
          </div>
          <div className="space-y-1">
            <div className="font-mono text-2xl sm:text-3xl font-semibold text-slate-900 tabular-nums">
              99.4% On-Time
            </div>
            <p className="text-sm text-slate-600">
              Supplier qualification milestones hit over 12 months
            </p>
          </div>
          <div className="space-y-1">
            <div className="font-mono text-2xl sm:text-3xl font-semibold text-slate-900 tabular-nums">
              $42,800 Saved
            </div>
            <p className="text-sm text-slate-600">
              Average quarterly variance reduction per regional lab
            </p>
          </div>
        </div>
      </section>

      {/* Capabilities Asymmetric Bento */}
      <section className="space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div className="space-y-2 max-w-2xl">
            <h2 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 text-balance">
              Built around real engineering handoffs
            </h2>
            <p className="text-base text-slate-600">
              Every module in this interactive demo uses shared state. Update a milestone in the workspace or sort batch spend in the ledger to test the workflow directly.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('ledger')}
            className="text-sm font-medium text-blue-700 hover:text-blue-800 hover:underline underline-offset-4 whitespace-nowrap shrink-0 cursor-pointer self-start sm:self-auto"
          >
            Inspect Live Ledger
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Primary Asymmetric Card */}
          <article className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between">
            <div className="aspect-[16/10] w-full overflow-hidden border-b border-slate-200 bg-slate-100">
              <ResilientImage
                src={FIELD_UNIT_IMAGE}
                alt="Matte charcoal anodized aluminum handheld telemetry device resting on concrete"
                fallbackTitle="Field Telemetry Unit"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6 sm:p-8 space-y-4">
              <div className="text-xs font-medium text-slate-500">
                <span>01. Milestone Tracking</span>
                <span aria-hidden="true"> · </span>
                <span>Field Telemetry Units</span>
              </div>
              <h3 className="font-display text-xl sm:text-2xl font-semibold text-slate-900">
                Trace mechanical tolerances alongside firmware readiness
              </h3>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
                Keep CNC batch checks, acoustic gasket samples, and signed calibration releases linked in one filterable board so hardware and firmware leads never ship out of sequence.
              </p>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onNavigate('workspace', 'Field Telemetry Units')}
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-blue-700 hover:text-blue-800 hover:underline underline-offset-4 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>Filter Telemetry Tasks in Workspace</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </article>

          {/* Secondary Stacked Column */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <article className="bg-white border border-slate-200 rounded-xl overflow-hidden flex-1 flex flex-col justify-between">
              <div className="aspect-[16/10] w-full overflow-hidden border-b border-slate-200 bg-slate-100">
                <ResilientImage
                  src={MODULAR_RACK_IMAGE}
                  alt="Precision modular aluminum compute chassis with braided slate cables on oak desk"
                  fallbackTitle="Modular Bench Assembly"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6 space-y-3">
                <div className="text-xs font-medium text-slate-500">
                  <span>02. Budget &amp; Hours Ledger</span>
                  <span aria-hidden="true"> · </span>
                  <span>Modular Bench Assembly</span>
                </div>
                <h3 className="font-display text-xl font-semibold text-slate-900">
                  Catch facility cost drift before batch close
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Compare hours logged against allocated lab budgets across Munich, Seattle, and Osaka with instant CSV export.
                </p>
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => onNavigate('ledger')}
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-blue-700 hover:text-blue-800 hover:underline underline-offset-4 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <span>View Operational Ledger</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </article>

            <article className="bg-white border border-slate-200 rounded-xl p-6 space-y-3">
              <div className="text-xs font-medium text-slate-500">
                <span>03. Capacity Modeling</span>
                <span aria-hidden="true"> · </span>
                <span>Interactive Estimator</span>
              </div>
              <h3 className="font-display text-xl font-semibold text-slate-900">
                Model engineering ROI by headcount and kit volume
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Adjust team size, active hardware kits, and review cadence to inspect projected monthly savings and payback timing.
              </p>
              <div className="pt-1">
                <button
                  type="button"
                  onClick={() => onNavigate('estimator')}
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-blue-700 hover:text-blue-800 hover:underline underline-offset-4 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>Open Capacity Estimator</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* Claim-to-Proof Testimonial & Walkthrough Form */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        {/* Attributable Testimonial */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <p className="text-xs font-medium text-slate-500">
              Customer Outcome · Northwind Robotics
            </p>
            <blockquote className="font-display text-xl sm:text-2xl font-medium text-slate-900 leading-snug">
              “Before Kestrel, our Munich and Seattle engineering leads reconciled field prototypes across four spreadsheets every Friday. Moving to a single milestone and budget ledger cut weekly review prep from six hours to twenty minutes.”
            </blockquote>
          </div>

          <div className="flex items-center gap-4 pt-4 border-t border-slate-100">
            <div className="w-12 h-12 rounded-full overflow-hidden border border-slate-200 shrink-0 bg-slate-100">
              <ResilientImage
                src={CLAIRE_PORTRAIT_IMAGE}
                alt="Portrait of Claire Bennett, VP of Operations at Northwind Robotics"
                fallbackTitle="CB"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-900">
                Claire Bennett
              </div>
              <div className="text-xs text-slate-500">
                VP of Operations, Northwind Robotics · 64 Engineers
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Walkthrough Request Form */}
        <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between">
          {submittedEmail ? (
            <div className="my-auto space-y-4 py-4">
              <div className="inline-flex items-center gap-2 text-emerald-700 font-medium text-sm">
                <CheckCircle2 className="w-5 h-5" />
                <span>Walkthrough request confirmed</span>
              </div>
              <h3 className="font-display text-2xl font-semibold text-slate-900">
                We sent a calendar link to {submittedEmail}
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Our solutions engineer will prepare a live sandbox configured for {teamSize}. Meanwhile, feel free to explore the interactive Workspace, Ledger, and Estimator tabs above.
              </p>
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSubmittedEmail(null);
                    setName('');
                    setEmail('');
                  }}
                  className="px-4 py-2 text-sm font-medium text-slate-700 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Submit Another Request
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleWalkthroughSubmit} noValidate className="space-y-5">
              <div className="space-y-1.5">
                <h3 className="font-display text-xl sm:text-2xl font-semibold text-slate-900">
                  Schedule a guided technical walkthrough
                </h3>
                <p className="text-sm text-slate-600">
                  See how Kestrel connects to your CAD release cadence and ERP cost centers.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="demo-name" className="block text-xs font-medium text-slate-700">
                    Full Name
                  </label>
                  <input
                    id="demo-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Claire Bennett"
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-blue-700"
                  />
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="demo-email" className="block text-xs font-medium text-slate-700">
                    Work Email
                  </label>
                  <input
                    id="demo-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="claire@northwind.io"
                    className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-blue-700"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="demo-size" className="block text-xs font-medium text-slate-700">
                  Engineering Team Size
                </label>
                <select
                  id="demo-size"
                  value={teamSize}
                  onChange={(e) => setTeamSize(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 focus:border-blue-700"
                >
                  <option value="5–14 engineers">5–14 engineers</option>
                  <option value="15–40 engineers">15–40 engineers</option>
                  <option value="41–120 engineers">41–120 engineers</option>
                  <option value="120+ engineers">120+ engineers</option>
                </select>
              </div>

              {errorMsg && (
                <p role="alert" className="text-xs font-medium text-red-600">
                  {errorMsg}
                </p>
              )}

              <div className="pt-1">
                <button
                  type="submit"
                  className="w-full sm:w-auto px-5 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 focus-visible:ring-offset-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Schedule Walkthrough
                </button>
              </div>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}
