import { useState, FormEvent } from 'react';
import {
  CheckCircle2,
  Clock,
  Eye,
  Circle,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { MilestoneItem, MilestoneStatus } from '../data/demoData';

interface WorkspaceViewProps {
  milestones: MilestoneItem[];
  initialProgramFilter?: string;
  onAddMilestone: (item: Omit<MilestoneItem, 'id' | 'code'>) => void;
  onUpdateMilestone: (id: string, patch: Partial<MilestoneItem>) => void;
  onDeleteMilestone: (id: string) => void;
}

const STATUS_FILTERS: Array<'All' | MilestoneStatus> = [
  'All',
  'Planned',
  'In Progress',
  'Review',
  'Complete',
];

const NEXT_STATUS: Record<MilestoneStatus, MilestoneStatus> = {
  Planned: 'In Progress',
  'In Progress': 'Review',
  Review: 'Complete',
  Complete: 'Planned',
};

function StatusIndicator({ status }: { status: MilestoneStatus }) {
  if (status === 'Complete') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap shrink-0">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Complete</span>
      </span>
    );
  }
  if (status === 'Review') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 whitespace-nowrap shrink-0">
        <Eye className="w-3.5 h-3.5" />
        <span>Review</span>
      </span>
    );
  }
  if (status === 'In Progress') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 whitespace-nowrap shrink-0">
        <Clock className="w-3.5 h-3.5" />
        <span>In Progress</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 whitespace-nowrap shrink-0">
      <Circle className="w-3.5 h-3.5" />
      <span>Planned</span>
    </span>
  );
}

export function WorkspaceView({
  milestones,
  initialProgramFilter = 'All Programs',
  onAddMilestone,
  onUpdateMilestone,
  onDeleteMilestone,
}: WorkspaceViewProps) {
  const [statusFilter, setStatusFilter] = useState<'All' | MilestoneStatus>('All');
  const [programFilter, setProgramFilter] = useState<string>(initialProgramFilter);
  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string>(milestones[0]?.id ?? '');
  const [showAddForm, setShowAddForm] = useState(false);

  // Add form state
  const [newTitle, setNewTitle] = useState('');
  const [newProgram, setNewProgram] = useState('Field Telemetry Units');
  const [newFacility, setNewFacility] = useState<'Munich' | 'Seattle' | 'Osaka'>('Munich');
  const [newOwner, setNewOwner] = useState('Henrik Lindqvist');
  const [newHours, setNewHours] = useState('16');
  const [formError, setFormError] = useState('');

  const programs = ['All Programs', ...Array.from(new Set(milestones.map((m) => m.program)))];

  const filtered = milestones.filter((item) => {
    const matchesStatus = statusFilter === 'All' || item.status === statusFilter;
    const matchesProgram = programFilter === 'All Programs' || item.program === programFilter;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q ||
      item.title.toLowerCase().includes(q) ||
      item.code.toLowerCase().includes(q) ||
      item.owner.toLowerCase().includes(q) ||
      item.facility.toLowerCase().includes(q);
    return matchesStatus && matchesProgram && matchesQuery;
  });

  const selectedItem =
    milestones.find((m) => m.id === selectedId) ?? filtered[0] ?? null;

  function handleCreateSubmit(e: FormEvent) {
    e.preventDefault();
    if (newTitle.trim().length < 4) {
      setFormError('Milestone title must be at least 4 characters.');
      return;
    }
    const parsedHours = Math.max(1, Number.parseInt(newHours, 10) || 8);
    onAddMilestone({
      title: newTitle.trim(),
      program: newProgram,
      facility: newFacility,
      owner: newOwner.trim() || 'Team Lead',
      dueDate: 'Dec 12, 2026',
      hoursLogged: parsedHours,
      status: 'Planned',
      notes: 'Created inside interactive demo workspace.',
    });
    setNewTitle('');
    setFormError('');
    setShowAddForm(false);
  }

  return (
    <div className="space-y-6 pb-16">
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-1">
          <h1 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900">
            Milestone Workspace
          </h1>
          <p className="text-sm text-slate-600">
            Select any item to inspect or edit engineering notes, advance status, or add a new task.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowAddForm((prev) => !prev)}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 self-start md:self-auto cursor-pointer"
        >
          {showAddForm ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
          <span>{showAddForm ? 'Close Form' : 'Add Milestone'}</span>
        </button>
      </div>

      {/* Inline Add Milestone Panel */}
      {showAddForm && (
        <form
          onSubmit={handleCreateSubmit}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold text-slate-900">
              New Engineering Milestone
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="sm:col-span-2 space-y-1">
              <label htmlFor="ms-title" className="block text-xs font-medium text-slate-700">
                Milestone Title
              </label>
              <input
                id="ms-title"
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="e.g., Pressure-test aluminum chassis seals"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>
            <div className="space-y-1">
              <label htmlFor="ms-program" className="block text-xs font-medium text-slate-700">
                Program
              </label>
              <select
                id="ms-program"
                value={newProgram}
                onChange={(e) => setNewProgram(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-700"
              >
                <option value="Field Telemetry Units">Field Telemetry Units</option>
                <option value="Modular Bench Assembly">Modular Bench Assembly</option>
                <option value="Supply Operations">Supply Operations</option>
              </select>
            </div>
            <div className="space-y-1">
              <label htmlFor="ms-facility" className="block text-xs font-medium text-slate-700">
                Facility
              </label>
              <select
                id="ms-facility"
                value={newFacility}
                onChange={(e) => setNewFacility(e.target.value as 'Munich' | 'Seattle' | 'Osaka')}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-700"
              >
                <option value="Munich">Munich</option>
                <option value="Seattle">Seattle</option>
                <option value="Osaka">Osaka</option>
              </select>
            </div>
            <div className="space-y-1">
              <label htmlFor="ms-owner" className="block text-xs font-medium text-slate-700">
                Owner
              </label>
              <input
                id="ms-owner"
                type="text"
                value={newOwner}
                onChange={(e) => setNewOwner(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>
            <div className="space-y-1">
              <label htmlFor="ms-hours" className="block text-xs font-medium text-slate-700">
                Initial Hours
              </label>
              <input
                id="ms-hours"
                type="number"
                min={1}
                max={400}
                value={newHours}
                onChange={(e) => setNewHours(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
              />
            </div>
          </div>
          {formError && <p className="text-xs font-medium text-red-600">{formError}</p>}
          <div className="flex items-center gap-3 pt-1">
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Create Milestone
            </button>
            <button
              type="button"
              onClick={() => {
                setShowAddForm(false);
                setFormError('');
              }}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
          {STATUS_FILTERS.map((status) => {
            const active = statusFilter === status;
            return (
              <button
                key={status}
                type="button"
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {status}
              </button>
            );
          })}
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <select
            aria-label="Filter by program"
            value={programFilter}
            onChange={(e) => setProgramFilter(e.target.value)}
            className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
          >
            {programs.map((prog) => (
              <option key={prog} value={prog}>
                {prog}
              </option>
            ))}
          </select>

          <div className="relative min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              aria-label="Search milestones"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search code, title, owner..."
              className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
            />
          </div>
        </div>
      </div>

      {/* Main Master-Detail Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Milestone List */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl divide-y divide-slate-100 overflow-hidden">
          {filtered.length === 0 ? (
            <div className="p-10 text-center space-y-3">
              <p className="text-sm font-medium text-slate-900">
                No milestones match your current filters.
              </p>
              <p className="text-xs text-slate-500">
                Clear the search or reset status filters to restore all items.
              </p>
              <button
                type="button"
                onClick={() => {
                  setStatusFilter('All');
                  setProgramFilter('All Programs');
                  setQuery('');
                }}
                className="px-4 py-2 text-xs font-medium text-blue-700 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            filtered.map((item) => {
              const isSelected = selectedItem?.id === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedId(item.id)}
                  className={`p-4 sm:p-5 transition-colors cursor-pointer flex items-start justify-between gap-4 ${
                    isSelected ? 'bg-slate-50' : 'hover:bg-slate-50/70'
                  }`}
                >
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono font-medium text-slate-700">{item.code}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate">{item.program}</span>
                    </div>
                    <h3 className="text-sm sm:text-base font-medium text-slate-900 leading-snug">
                      {item.title}
                    </h3>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <span>{item.facility}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.owner}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{item.hoursLogged} hrs</span>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <StatusIndicator status={item.status} />
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateMilestone(item.id, { status: NEXT_STATUS[item.status] });
                      }}
                      className="text-xs font-medium text-slate-600 hover:text-blue-700 underline underline-offset-4 whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Advance Status
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Detail Inspector */}
        <aside className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          {selectedItem ? (
            <>
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="space-y-1">
                  <div className="text-xs font-mono text-slate-500">
                    {selectedItem.code} · Due {selectedItem.dueDate}
                  </div>
                  <h2 className="font-display text-xl font-semibold text-slate-900">
                    {selectedItem.title}
                  </h2>
                </div>
                <button
                  type="button"
                  aria-label="Delete milestone"
                  onClick={() => onDeleteMilestone(selectedItem.id)}
                  className="p-2 text-slate-400 hover:text-red-600 rounded-lg hover:bg-slate-50 transition-colors shrink-0 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="inspect-status" className="block text-xs font-medium text-slate-600">
                    Status
                  </label>
                  <select
                    id="inspect-status"
                    value={selectedItem.status}
                    onChange={(e) =>
                      onUpdateMilestone(selectedItem.id, {
                        status: e.target.value as MilestoneStatus,
                      })
                    }
                    className="w-full px-3 py-2 text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  >
                    <option value="Planned">Planned</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Review">Review</option>
                    <option value="Complete">Complete</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label htmlFor="inspect-facility" className="block text-xs font-medium text-slate-600">
                    Facility
                  </label>
                  <select
                    id="inspect-facility"
                    value={selectedItem.facility}
                    onChange={(e) =>
                      onUpdateMilestone(selectedItem.id, {
                        facility: e.target.value as 'Munich' | 'Seattle' | 'Osaka',
                      })
                    }
                    className="w-full px-3 py-2 text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  >
                    <option value="Munich">Munich</option>
                    <option value="Seattle">Seattle</option>
                    <option value="Osaka">Osaka</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label htmlFor="inspect-owner" className="block text-xs font-medium text-slate-600">
                    Lead Owner
                  </label>
                  <input
                    id="inspect-owner"
                    type="text"
                    value={selectedItem.owner}
                    onChange={(e) =>
                      onUpdateMilestone(selectedItem.id, { owner: e.target.value })
                    }
                    className="w-full px-3 py-2 text-xs text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  />
                </div>

                <div className="space-y-1">
                  <label htmlFor="inspect-hours" className="block text-xs font-medium text-slate-600">
                    Hours Logged
                  </label>
                  <input
                    id="inspect-hours"
                    type="number"
                    min={0}
                    max={999}
                    value={selectedItem.hoursLogged}
                    onChange={(e) =>
                      onUpdateMilestone(selectedItem.id, {
                        hoursLogged: Math.max(0, Number.parseInt(e.target.value, 10) || 0),
                      })
                    }
                    className="w-full px-3 py-2 text-xs font-mono tabular-nums text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="inspect-notes" className="block text-xs font-medium text-slate-600">
                  Engineering Notes
                </label>
                <textarea
                  id="inspect-notes"
                  rows={4}
                  value={selectedItem.notes}
                  onChange={(e) =>
                    onUpdateMilestone(selectedItem.id, { notes: e.target.value })
                  }
                  className="w-full px-3 py-2.5 text-sm text-slate-800 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700 leading-relaxed"
                />
              </div>
            </>
          ) : (
            <div className="py-12 text-center text-sm text-slate-500">
              Select a milestone from the list to inspect or edit its parameters.
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
