import { useState } from 'react';
import {
  AlertTriangle,
  ArrowUpDown,
  CheckCircle2,
  Download,
  RefreshCw,
  Search,
  XCircle,
} from 'lucide-react';
import { LedgerEntry, LedgerStatus } from '../data/demoData';

interface LedgerViewProps {
  entries: LedgerEntry[];
}

type SortKey = 'batchCode' | 'project' | 'facility' | 'hoursLogged' | 'budgetSpent' | 'utilization';

function LedgerStatusBadge({ status }: { status: LedgerStatus }) {
  if (status === 'Nominal') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Nominal</span>
      </span>
    );
  }
  if (status === 'Watch') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 whitespace-nowrap">
        <AlertTriangle className="w-3.5 h-3.5" />
        <span>Watch</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700 whitespace-nowrap">
      <XCircle className="w-3.5 h-3.5" />
      <span>Overrun</span>
    </span>
  );
}

export function LedgerView({ entries }: LedgerViewProps) {
  const [regionFilter, setRegionFilter] = useState<'All' | 'Munich' | 'Seattle' | 'Osaka'>('All');
  const [query, setQuery] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('batchCode');
  const [sortAsc, setSortAsc] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  function toggleSort(key: SortKey) {
    if (sortKey === key) {
      setSortAsc((prev) => !prev);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
  }

  function handleSimulateRefresh() {
    setIsRefreshing(true);
    window.setTimeout(() => {
      setIsRefreshing(false);
    }, 650);
  }

  const filtered = entries
    .filter((row) => {
      const matchesRegion = regionFilter === 'All' || row.facility === regionFilter;
      const q = query.trim().toLowerCase();
      const matchesQuery =
        !q ||
        row.batchCode.toLowerCase().includes(q) ||
        row.project.toLowerCase().includes(q) ||
        row.facility.toLowerCase().includes(q);
      return matchesRegion && matchesQuery;
    })
    .sort((a, b) => {
      let cmp = 0;
      if (sortKey === 'utilization') {
        const uA = a.budgetSpent / a.budgetAllocated;
        const uB = b.budgetSpent / b.budgetAllocated;
        cmp = uA - uB;
      } else if (sortKey === 'hoursLogged' || sortKey === 'budgetSpent') {
        cmp = a[sortKey] - b[sortKey];
      } else {
        cmp = a[sortKey].localeCompare(b[sortKey]);
      }
      return sortAsc ? cmp : -cmp;
    });

  const totalHours = filtered.reduce((acc, r) => acc + r.hoursLogged, 0);
  const totalSpent = filtered.reduce((acc, r) => acc + r.budgetSpent, 0);
  const totalAllocated = filtered.reduce((acc, r) => acc + r.budgetAllocated, 0);

  function handleExportCsv() {
    const header = ['Batch Code', 'Project', 'Facility', 'Updated', 'Hours Logged', 'Spent USD', 'Allocated USD', 'Status'];
    const lines = filtered.map((r) => [
      r.batchCode,
      `"${r.project.replace(/"/g, '""')}"`,
      r.facility,
      r.updatedAt,
      r.hoursLogged,
      r.budgetSpent,
      r.budgetAllocated,
      r.status,
    ].join(','));
    const csv = [header.join(','), ...lines].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'kestrel-operational-ledger.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6 pb-16">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-1">
          <h1 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900">
            Operational Ledger
          </h1>
          <p className="text-sm text-slate-600">
            Sort batch allocations, filter by facility, inspect loading states, or export filtered rows to CSV.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleSimulateRefresh}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Sync Ledger</span>
          </button>
          <button
            type="button"
            onClick={handleExportCsv}
            disabled={filtered.length === 0}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-40 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-200 rounded-xl p-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
          {(['All', 'Munich', 'Seattle', 'Osaka'] as const).map((region) => (
            <button
              key={region}
              type="button"
              onClick={() => setRegionFilter(region)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                regionFilter === region
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {region === 'All' ? 'All Facilities' : region}
            </button>
          ))}
        </div>

        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            aria-label="Search ledger entries"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter by batch code or project..."
            className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-700"
          />
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-600">
                <th className="py-3 px-4 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => toggleSort('batchCode')}
                    className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                  >
                    <span>Batch Code</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-3 px-4 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => toggleSort('project')}
                    className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                  >
                    <span>Project</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-3 px-4 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => toggleSort('facility')}
                    className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                  >
                    <span>Facility</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-3 px-4 text-right whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => toggleSort('hoursLogged')}
                    className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                  >
                    <span>Hours</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-3 px-4 text-right whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => toggleSort('budgetSpent')}
                    className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                  >
                    <span>Spend / Budget</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-3 px-4 text-right whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => toggleSort('utilization')}
                    className="inline-flex items-center gap-1 hover:text-slate-900 cursor-pointer"
                  >
                    <span>Utilization</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </button>
                </th>
                <th className="py-3 px-4 whitespace-nowrap">State</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100 text-sm">
              {isRefreshing ? (
                Array.from({ length: 5 }).map((_, idx) => (
                  <tr key={idx} className="h-[44px]">
                    <td className="px-4 py-2.5"><div className="h-3.5 w-24 bg-slate-200 rounded animate-pulse" /></td>
                    <td className="px-4 py-2.5"><div className="h-3.5 w-48 bg-slate-200 rounded animate-pulse" /></td>
                    <td className="px-4 py-2.5"><div className="h-3.5 w-16 bg-slate-200 rounded animate-pulse" /></td>
                    <td className="px-4 py-2.5"><div className="h-3.5 w-12 ml-auto bg-slate-200 rounded animate-pulse" /></td>
                    <td className="px-4 py-2.5"><div className="h-3.5 w-28 ml-auto bg-slate-200 rounded animate-pulse" /></td>
                    <td className="px-4 py-2.5"><div className="h-3.5 w-12 ml-auto bg-slate-200 rounded animate-pulse" /></td>
                    <td className="px-4 py-2.5"><div className="h-3.5 w-16 bg-slate-200 rounded animate-pulse" /></td>
                  </tr>
                ))
              ) : filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 px-4 text-center">
                    <div className="space-y-3">
                      <p className="text-sm font-medium text-slate-900">
                        No ledger batches match your search.
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setRegionFilter('All');
                          setQuery('');
                        }}
                        className="px-4 py-2 text-xs font-medium text-blue-700 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                      >
                        Reset Filters
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map((row) => {
                  const pct = Math.round((row.budgetSpent / row.budgetAllocated) * 100);
                  return (
                    <tr key={row.id} className="h-[44px] hover:bg-slate-50/80 transition-colors">
                      <td className="py-2.5 px-4 font-mono text-xs font-medium text-slate-800 whitespace-nowrap">
                        {row.batchCode}
                      </td>
                      <td className="py-2.5 px-4 text-slate-900 font-medium whitespace-nowrap">
                        {row.project}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 whitespace-nowrap">
                        {row.facility}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-xs text-slate-700 tabular-nums whitespace-nowrap">
                        {row.hoursLogged} hrs
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-xs text-slate-700 tabular-nums whitespace-nowrap">
                        ${row.budgetSpent.toLocaleString()} / ${row.budgetAllocated.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-xs font-medium text-slate-900 tabular-nums whitespace-nowrap">
                        {pct}%
                      </td>
                      <td className="py-2.5 px-4 whitespace-nowrap">
                        <LedgerStatusBadge status={row.status} />
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>

            {!isRefreshing && filtered.length > 0 && (
              <tfoot>
                <tr className="border-t border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-900">
                  <td className="py-3 px-4 whitespace-nowrap">
                    Totals ({filtered.length} batches)
                  </td>
                  <td className="py-3 px-4" colSpan={2} />
                  <td className="py-3 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                    {totalHours.toLocaleString()} hrs
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                    ${totalSpent.toLocaleString()} / ${totalAllocated.toLocaleString()}
                  </td>
                  <td className="py-3 px-4 text-right font-mono tabular-nums whitespace-nowrap">
                    {totalAllocated > 0 ? Math.round((totalSpent / totalAllocated) * 100) : 0}%
                  </td>
                  <td className="py-3 px-4" />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
}
