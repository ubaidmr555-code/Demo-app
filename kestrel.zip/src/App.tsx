/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import {
  INITIAL_LEDGER,
  INITIAL_MILESTONES,
  MilestoneItem,
} from './data/demoData';
import { AppView, OverviewSection } from './components/OverviewSection';
import { WorkspaceView } from './components/WorkspaceView';
import { LedgerView } from './components/LedgerView';
import { EstimatorView } from './components/EstimatorView';

const NAV_ITEMS: Array<{ id: AppView; label: string }> = [
  { id: 'overview', label: 'Overview' },
  { id: 'workspace', label: 'Workspace' },
  { id: 'ledger', label: 'Ledger' },
  { id: 'estimator', label: 'Estimator' },
];

export default function App() {
  const [activeView, setActiveView] = useState<AppView>('overview');
  const [workspaceProgramFilter, setWorkspaceProgramFilter] = useState<string>('All Programs');
  const [milestones, setMilestones] = useState<MilestoneItem[]>(INITIAL_MILESTONES);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  function handleNavigate(view: AppView, programFilter?: string) {
    if (programFilter) {
      setWorkspaceProgramFilter(programFilter);
    } else if (view === 'workspace') {
      setWorkspaceProgramFilter('All Programs');
    }
    setActiveView(view);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleAddMilestone(item: Omit<MilestoneItem, 'id' | 'code'>) {
    const nextNum = 120 + milestones.length;
    const created: MilestoneItem = {
      ...item,
      id: `ms-${Date.now()}`,
      code: `KST-${nextNum}`,
    };
    setMilestones((prev) => [created, ...prev]);
  }

  function handleUpdateMilestone(id: string, patch: Partial<MilestoneItem>) {
    setMilestones((prev) =>
      prev.map((m) => (m.id === id ? { ...m, ...patch } : m))
    );
  }

  function handleDeleteMilestone(id: string) {
    setMilestones((prev) => prev.filter((m) => m.id !== id));
  }

  function handleResetDemo() {
    setMilestones(INITIAL_MILESTONES);
    setWorkspaceProgramFilter('All Programs');
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark */}
          <button
            type="button"
            onClick={() => handleNavigate('overview')}
            className="font-display text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700 rounded"
          >
            Kestrel
          </button>

          {/* Zone 2: 4 single-line text nav links */}
          <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-7">
            {NAV_ITEMS.map((item) => {
              const active = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer py-1 border-b-2 ${
                    active
                      ? 'text-slate-900 border-blue-700'
                      : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 primary action + mobile menu toggle */}
          <div className="flex items-center gap-3 shrink-0">
            {activeView === 'overview' ? (
              <button
                type="button"
                onClick={() => handleNavigate('workspace')}
                className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
              >
                Open Workspace
              </button>
            ) : (
              <button
                type="button"
                onClick={handleResetDemo}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-700"
              >
                Reset Demo Data
              </button>
            )}

            <button
              type="button"
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              className="md:hidden p-2 text-slate-700 hover:text-slate-900 rounded-lg border border-slate-200 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <nav
            aria-label="Mobile navigation"
            className="md:hidden border-t border-slate-200 bg-white px-4 py-3 flex flex-wrap gap-2"
          >
            {NAV_ITEMS.map((item) => {
              const active = activeView === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`px-3 py-2 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12">
        {activeView === 'overview' && (
          <OverviewSection onNavigate={handleNavigate} />
        )}
        {activeView === 'workspace' && (
          <WorkspaceView
            key={workspaceProgramFilter}
            milestones={milestones}
            initialProgramFilter={workspaceProgramFilter}
            onAddMilestone={handleAddMilestone}
            onUpdateMilestone={handleUpdateMilestone}
            onDeleteMilestone={handleDeleteMilestone}
          />
        )}
        {activeView === 'ledger' && <LedgerView entries={INITIAL_LEDGER} />}
        {activeView === 'estimator' && <EstimatorView />}
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 bg-white mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-3">
            <span className="font-display font-semibold text-slate-900">Kestrel</span>
            <span aria-hidden="true">·</span>
            <span>Interactive Operations Demo</span>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
