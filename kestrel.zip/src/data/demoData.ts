export type MilestoneStatus = 'Planned' | 'In Progress' | 'Review' | 'Complete';

export interface MilestoneItem {
  id: string;
  code: string;
  title: string;
  program: string;
  facility: 'Munich' | 'Seattle' | 'Osaka';
  owner: string;
  dueDate: string;
  hoursLogged: number;
  status: MilestoneStatus;
  notes: string;
}

export type LedgerStatus = 'Nominal' | 'Watch' | 'Overrun';

export interface LedgerEntry {
  id: string;
  batchCode: string;
  project: string;
  facility: 'Munich' | 'Seattle' | 'Osaka';
  updatedAt: string;
  hoursLogged: number;
  budgetSpent: number;
  budgetAllocated: number;
  status: LedgerStatus;
}

export const INITIAL_MILESTONES: MilestoneItem[] = [
  {
    id: 'ms-1',
    code: 'KST-104',
    title: 'Anodized sensor enclosure tolerance check',
    program: 'Field Telemetry Units',
    facility: 'Munich',
    owner: 'Henrik Lindqvist',
    dueDate: 'Nov 24, 2026',
    hoursLogged: 28,
    status: 'In Progress',
    notes: 'Verify +/- 0.05mm chamfer consistency across CNC batch 14 before sealing gasket assembly.'
  },
  {
    id: 'ms-2',
    code: 'KST-109',
    title: 'Thermal soak verification on modular compute chassis',
    program: 'Modular Bench Assembly',
    facility: 'Seattle',
    owner: 'Maya Patel',
    dueDate: 'Nov 26, 2026',
    hoursLogged: 42,
    status: 'Review',
    notes: '72-hour continuous load test complete. Peak manifold exhaust stabilized at 41.2 C.'
  },
  {
    id: 'ms-3',
    code: 'KST-112',
    title: 'Braided harness strain-relief pull certification',
    program: 'Modular Bench Assembly',
    facility: 'Osaka',
    owner: 'Kenji Takahashi',
    dueDate: 'Nov 29, 2026',
    hoursLogged: 16,
    status: 'Planned',
    notes: 'Schedule tensile rig slots for the updated 12-pin shielded umbilical assemblies.'
  },
  {
    id: 'ms-4',
    code: 'KST-098',
    title: 'Field calibration firmware signing & release',
    program: 'Field Telemetry Units',
    facility: 'Seattle',
    owner: 'Claire Bennett',
    dueDate: 'Nov 19, 2026',
    hoursLogged: 54,
    status: 'Complete',
    notes: 'Signed production image deployed to 140 handheld telemetry units with zero rollback incidents.'
  },
  {
    id: 'ms-5',
    code: 'KST-115',
    title: 'Acoustic dampening gasket supplier qualification',
    program: 'Field Telemetry Units',
    facility: 'Munich',
    owner: 'Lukas Weber',
    dueDate: 'Dec 03, 2026',
    hoursLogged: 12,
    status: 'In Progress',
    notes: 'Comparing Shore 50A silicone samples from two Bavarian vendors under cold-start cycling.'
  },
  {
    id: 'ms-6',
    code: 'KST-118',
    title: 'Quarterly spares buffer allocation audit',
    program: 'Supply Operations',
    facility: 'Osaka',
    owner: 'Yumi Sato',
    dueDate: 'Dec 06, 2026',
    hoursLogged: 9,
    status: 'Planned',
    notes: 'Reconcile Q1 safety stock targets against updated lead times for custom OLED displays.'
  }
];

export const INITIAL_LEDGER: LedgerEntry[] = [
  {
    id: 'ld-1',
    batchCode: 'MUN-2611-A',
    project: 'Field Telemetry Enclosure Run',
    facility: 'Munich',
    updatedAt: '2026-11-17',
    hoursLogged: 184,
    budgetSpent: 34200,
    budgetAllocated: 40000,
    status: 'Nominal'
  },
  {
    id: 'ld-2',
    batchCode: 'SEA-2611-B',
    project: 'Modular Compute Chassis Validation',
    facility: 'Seattle',
    updatedAt: '2026-11-17',
    hoursLogged: 246,
    budgetSpent: 46800,
    budgetAllocated: 50000,
    status: 'Watch'
  },
  {
    id: 'ld-3',
    batchCode: 'OSA-2611-C',
    project: 'Shielded Harness Assembly Line',
    facility: 'Osaka',
    updatedAt: '2026-11-16',
    hoursLogged: 128,
    budgetSpent: 21400,
    budgetAllocated: 30000,
    status: 'Nominal'
  },
  {
    id: 'ld-4',
    batchCode: 'MUN-2611-D',
    project: 'Cold-Chamber Gasket Qualification',
    facility: 'Munich',
    updatedAt: '2026-11-15',
    hoursLogged: 96,
    budgetSpent: 19800,
    budgetAllocated: 18000,
    status: 'Overrun'
  },
  {
    id: 'ld-5',
    batchCode: 'SEA-2611-E',
    project: 'OLED Calibration Rig Build',
    facility: 'Seattle',
    updatedAt: '2026-11-14',
    hoursLogged: 142,
    budgetSpent: 25600,
    budgetAllocated: 32000,
    status: 'Nominal'
  },
  {
    id: 'ld-6',
    batchCode: 'OSA-2611-F',
    project: 'Automated Optical Inspection Cell',
    facility: 'Osaka',
    updatedAt: '2026-11-13',
    hoursLogged: 210,
    budgetSpent: 44100,
    budgetAllocated: 48000,
    status: 'Watch'
  },
  {
    id: 'ld-7',
    batchCode: 'MUN-2611-G',
    project: 'Bench Power Distribution Unit',
    facility: 'Munich',
    updatedAt: '2026-11-11',
    hoursLogged: 112,
    budgetSpent: 18900,
    budgetAllocated: 26000,
    status: 'Nominal'
  }
];

export const HERO_IMAGE = '/src/assets/images/hero_studio_workspace_1794968266879.jpg';
export const FIELD_UNIT_IMAGE = '/src/assets/images/hardware_field_unit_1794968267536.jpg';
export const MODULAR_RACK_IMAGE = '/src/assets/images/modular_rack_assembly_1794968266900.jpg';
export const CLAIRE_PORTRAIT_IMAGE = '/src/assets/images/portrait_claire_bennett_1794968268438.jpg';
